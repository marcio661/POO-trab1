
package questao1;

/**
 *
 * @author Marcio
 */
abstract class Main {

    
    public static void main(String[] args) {
        CalculadoraCompleta calculadora = new CalculadoraCompleta();
        
        double resultadoSoma = calculadora.soma(2,7);
        double resultadoSubtracao = calculadora.subtracao(10, 8);
        double resultadoMultiplicacao = calculadora.multiplicacao(4, 6);
        double resultadodivisao = calculadora.divisao(4, 2);
        double resultadoraizQuadrada = calculadora.raizQuadrada(81);
        double resultadopotenciaAoQuadrado = calculadora.potenciaAoQuadrado(5);
        
        System.out.println("Resultado da Soma: " +resultadoSoma);
        System.out.println("Resultado da Subtração: " +resultadoSubtracao);
        System.out.println("Resultado da Multiplicação: " +resultadoMultiplicacao);
        System.out.println("Resultado da Divisão: " +resultadodivisao);
        System.out.println("Resultado da Raiz ao quadrado: " +resultadoraizQuadrada);
        System.out.println("Resultado da Potencia ao Quadrado: " +resultadopotenciaAoQuadrado);
    }
    
}
