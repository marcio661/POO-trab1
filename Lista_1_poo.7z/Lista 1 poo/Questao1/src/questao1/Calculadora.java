/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao1;

/**
 *
 * @author souza
 */
public abstract class Calculadora {
    public abstract double soma(double a, double b);
    public abstract double subtracao(double a, double b);
    public abstract double multiplicacao(double a, double b);
    public abstract double divisao(double a, double b);
}
