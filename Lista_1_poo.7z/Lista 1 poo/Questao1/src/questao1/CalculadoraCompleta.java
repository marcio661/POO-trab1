/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao1;

/**
 *
 * @author souza
 */
public class CalculadoraCompleta extends Calculadora {
    public double soma(double a, double b){
    return a+b;
    }
    public double subtracao(double a, double b){
    return a-b;
    }
    public double multiplicacao(double a, double b){
    return a*b;
    }
    public double divisao (double a, double b){
    return a/b;
    }
    public double raizQuadrada(double a){
    return Math.sqrt(a);
    }
    public double potenciaAoQuadrado(double a){
    return Math.pow(a, 2);
    }
    
}
