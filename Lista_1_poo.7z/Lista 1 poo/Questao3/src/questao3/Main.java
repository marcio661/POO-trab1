
package questao3;

import java.util.ArrayList;

/**
 *
 * @author souza
 */
public class Main {

    
    public static void main(String[] args) {
         Aluno aluno = new Aluno("123456789", "Vitoria", 21, "Direito");
         
         Disciplina disciplina1 = new Disciplina("Direito Civil");
         Disciplina disciplina2 = new Disciplina("Direito Penal");
         
         aluno.adicionarDisciplina(disciplina1);
         aluno.adicionarDisciplina(disciplina2);
         
         System.out.println("CPF: " + aluno.getCpf());
         System.out.println("Nome: " + aluno.getNome());
         System.out.println("Idade: " + aluno.getIdade());
         System.out.println("Curso: " + aluno.getCurso());
         ArrayList<Disciplina> disciplinas = aluno.getDisciplinas();
         System.out.println("Disciplinas:");
         for (Disciplina disciplina : disciplinas){
         System.out.println("- " + disciplina.getNome());
    }
    
  }
}
