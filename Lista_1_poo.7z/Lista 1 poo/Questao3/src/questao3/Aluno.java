
package questao3;

import java.util.ArrayList;

/**
 *
 * @author Marcio
 */
public class Aluno extends Pessoa {
    private String curso;
    private ArrayList<Disciplina> disciplinas;
    
    public Aluno(String cpf, String nome, int idade, String curso){
    super(cpf, nome, idade);
    this.curso=curso;
    this.disciplinas = new ArrayList<Disciplina>();
    }
    public void adicionarDisciplina(Disciplina disciplina){
    disciplinas.add(disciplina);
    }
    public void removerDisciplina(Disciplina disciplina){
    disciplinas.remove(disciplina);
    }
    public String getCurso(){
    return curso;
    }
    public void setCurso(String curso){
    this.curso = curso;
    }
    public ArrayList<Disciplina> getDisciplinas(){
    return disciplinas;
    }
    public void setDisciplinas(ArrayList<Disciplina> disciplinas){
    this.disciplinas = disciplinas;
    }
            
    
}
