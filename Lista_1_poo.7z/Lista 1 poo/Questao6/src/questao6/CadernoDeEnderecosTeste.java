
package questao6;

/**
 *
 * @author souza
 */
public class CadernoDeEnderecosTeste {

   
    public static void main(String[] args) {
        CadernoDeEnderecos pessoa = new CadernoDeEnderecos("Vitória", "123456789", "vitoria@gmail.com", "25/01", "Rua A, 123");
       System.out.println("Nome: " +pessoa.getNome());
       System.out.println("Telefone: " +pessoa.getTelefone());
       System.out.println("Email: " +pessoa.getEmail());
       System.out.println("Data de aniversário: " +pessoa.getDataAniversario());
       System.out.println("Endereço: " +pessoa.getEndereco());
       
       pessoa.setNome("Marcio");
       pessoa.setTelefone("987654321");
       pessoa.setEmail("Marcio@gmail.com");
       pessoa.setDataAniversario("23/11");
       pessoa.setEndereco("Avenida B, 456");
       
       System.out.println("\nNome: " +pessoa.getNome());
       System.out.println("Telefone: " +pessoa.getTelefone());
       System.out.println("Email: " +pessoa.getEmail());
       System.out.println("Data De Aniversário: " +pessoa.getDataAniversario());
       System.out.println("Endereço: " +pessoa.getEndereco());
    }
    
}
