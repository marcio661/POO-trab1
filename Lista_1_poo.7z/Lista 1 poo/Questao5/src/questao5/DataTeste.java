
package questao5;

/**
 *
 * @author souza
 */
public class DataTeste {

  
    public static void main(String[] args) {
        Data data = new Data(25, 1, 2002);
        data.exibeData();
        
        
    }
    
}
