
package questao4;

/**
 *
 * @author souza
 */
public class Main {

    
    public static void main(String[] args) {
        Motocicleta motocicleta = new Motocicleta("Vermelho", 100, 2010, 15000.0, "Scooter");
        motocicleta.setTipo("Scooter");
        Carro carro = new Carro("Azul", 300, 2021, 110000.0, 4);
        carro.setNumeroPortas(4);
        Caminhao caminhao = new Caminhao("Verde", 250, 2016, 200000.0, 500);
        caminhao.setCapacidadeCarga(500);
        
       System.out.println("Motocicleta: ");
       System.out.println("Cor: " +motocicleta.getCor());
       System.out.println("Potência: " +motocicleta.getPotencia());
       System.out.println("Ano de Fabricação: " +motocicleta.getAnoFabricacao());
       System.out.println("Valor: " +motocicleta.getValor());
       System.out.println("Tipo: " +motocicleta.getTipo());
       
       System.out.println();
       
       System.out.println("Carro:");
       System.out.println("Cor: " +carro.getCor());
       System.out.println("Potência: " +carro.getPotencia());
       System.out.println("Ano de fabricação: " +carro.getAnoFabricacao());
       System.out.println("Valor: " +carro.getValor());
       System.out.println("Número de Portas: " +carro.getNumeroPortas());
       
       System.out.println();
       System.out.println("Caminhão: ");
       System.out.println("Cor: " +caminhao.getCor());
       System.out.println("Potência: " +caminhao.getPotencia());
       System.out.println("Ano de Fabricação: " +caminhao.getAnoFabricacao());
       System.out.println("Valor: " +caminhao.getValor());
       System.out.println("Capacidade de Carga: " +caminhao.getCapacidadeCarga());
       
    }
    
}
