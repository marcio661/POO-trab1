
package questao4;

/**
 *
 * @author souza
 */
public class Motocicleta extends Veiculo {
    private String tipo;
    
    public Motocicleta(String cor, int potencia, int anoFabricacao, double valor, String tipo){
    super(cor, potencia, anoFabricacao, valor);
    this.tipo=tipo;
    }
    public String getTipo(){
    return tipo;
    }
    public void setTipo(String tipo){
    this.tipo=tipo;
    }
    
}
