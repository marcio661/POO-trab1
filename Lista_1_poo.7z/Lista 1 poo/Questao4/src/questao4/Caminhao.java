/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao4;

/**
 *
 * @author souza
 */
public class Caminhao extends Veiculo {
    private int capacidadeCarga;
    
    public Caminhao(String cor, int potencia, int anoFabricacao, double valor, int capacidadeCarga){
    super(cor, potencia, anoFabricacao, valor);
    this.capacidadeCarga=capacidadeCarga;
    }
    public int getCapacidadeCarga(){
    return capacidadeCarga;
    }
    public void setCapacidadeCarga(int capacidadeCarga){
    this.capacidadeCarga = capacidadeCarga;
    }
}
