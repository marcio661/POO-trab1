/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao2;

/**
 *
 * @author souza
 */
public class Aluno extends Pessoa{
    private String curso;
    private String disciplina;
    
    public Aluno(String cpf, String nome, int idade, String curso, String disciplina){
    super(cpf, nome, idade);
    this.curso = curso;
    this.disciplina = disciplina;
    }
    public String getCurso(){
    return curso;
    }
    public void setCurso(String curso){
    this.curso=curso;
    }
    
    public String getDisciplina(){
    return disciplina;
    }
    public void setDisciplina(String disciplina){
    this.disciplina = disciplina;
    }
}
