
package questao8;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
/**
 *
 * @author souza
 */
public class Pais {
    private String nome;
    private String capital;
    private double dimensão;
    private List<Pais> fronteiras;
    
    public Pais(String nome, String capital, double dimensão){
    this.nome = nome;
    this.capital = capital;
    this.dimensão = dimensão;
    this.fronteiras = new ArrayList<>();
    }
    public String getNome(){
    return nome;
    }
    public String getCapital(){
    return capital;
    }
    public double getDimensão(){
    return dimensão;
    }
    public void definirFronteira(Pais pais){
    if(!equals(pais)){
    fronteiras.add(pais);
    }
    }
    public List<Pais> getFronteiras(){
    return fronteiras;
    }
    public List<Pais> obterVizinhosComuns(Pais outroPais){
    List<Pais> vizinhosComuns = new ArrayList<>();
    for (Pais pais : fronteiras){
    if(outroPais.fronteiras.contains(pais)){
    vizinhosComuns.add(pais);
    }
    }
    return vizinhosComuns;
    }
    @Override
    public boolean equals(Object outro){
    if(this == outro){
    return true;
    }
    if(outro == null || getClass() != outro.getClass()){
    return false;
    }
    Pais pais = (Pais) outro;
    return Objects.equals(nome, pais.nome)&&
    Objects.equals (capital, pais.capital);
    }
    @Override
    public int hashCode(){
    return Objects.hash(nome, capital);
    }
}
