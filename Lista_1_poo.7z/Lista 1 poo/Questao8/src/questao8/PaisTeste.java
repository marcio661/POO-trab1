
package questao8;
import java.util.List;
/**
 *
 * @author souza
 */
public class PaisTeste {

    
    public static void main(String[] args) {
       Pais brasil = new Pais("Brasil", "Brasilia", 8515767);
       Pais argentina = new Pais("Argentina", "Buenos Aires", 2780400);
       Pais paraguai = new Pais("Paraguai", "Assunção", 406752);
       Pais uruguai = new Pais("Uruguai", "Montevidéu", 176215);
       Pais bolivia = new Pais("Bolivia", "La Paz", 1098581);
       
       brasil.definirFronteira(argentina);
       brasil.definirFronteira(paraguai);
       brasil.definirFronteira(uruguai);
       brasil.definirFronteira(bolivia);
       
       argentina.definirFronteira(brasil);
       argentina.definirFronteira(uruguai);
       
       List<Pais> fronteirasDoBrasil = brasil.getFronteiras();
       System.out.println("Fronteiras do Brasil: ");
       for (Pais pais : fronteirasDoBrasil){
       System.out.println(pais.getNome());
       }
       List<Pais> vizinhosComuns = brasil.obterVizinhosComuns(argentina);
       System.out.println("\nVizinhos comuns entre Brasil e Argentina:");
       for (Pais pais : vizinhosComuns){
       System.out.println(pais.getNome());
       }
    }
    
}
