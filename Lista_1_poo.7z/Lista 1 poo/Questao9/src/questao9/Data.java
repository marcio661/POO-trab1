/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao9;



/**
 *
 * @author souza
 */
public class Data {
    private int dia;
    private int mês;
    private int ano;
    
    public Data(int dia, int mês, int ano){
    this.dia = dia;
    this.mês = mês;
    this.ano = ano;
    }
    public int getDia(){
    return dia;
    }
    
    public int getMês(){
    return mês;
    }
    
    public int getAno(){
    return ano;
    }
    
    
    @Override
    public String toString(){
    return dia + "/" + mês + "/" + ano;
    }
    
}
