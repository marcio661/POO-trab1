
package questao9;

/**
 *
 * @author souza
 */
public class TesteEntradaDeCinema {

   
    public static void main(String[] args) {
       Data dataFilme = new Data(15, 6, 2023);
       EntradaDeCinema entrada = new EntradaDeCinema(dataFilme, "18:30", "Sala 1", 30.0);
       Data dataNascimento = new Data (10, 5, 2010);
  
       int carteiraEstudante = 123456;
       entrada.calculaDesconto(dataNascimento);
       entrada.calculaDesconto(dataNascimento, carteiraEstudante);
       entrada.calculaDescontoHorário();
       System.out.println(entrada);
       
       
    }
    
}

