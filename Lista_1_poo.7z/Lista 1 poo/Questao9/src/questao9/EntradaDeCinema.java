
package questao9;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;

/**
 *
 * @author souza
 */
public class EntradaDeCinema {
    private Data dataFilme;
    private String horário;
    private String sala;
    private double valor;
    
    public EntradaDeCinema(Data dataFilme, String horário, String sala, double valor){
    this.dataFilme = dataFilme;
    this.horário = horário;
    this.sala = sala;
    this.valor = valor;
    }
    public void calculaDesconto(Data dataNascimento){
    if (calcularIdade(dataNascimento)<12){
    valor *=0.5;
            }
    }
    
    public void calculaDesconto(Data dataNascimento, int CarteiraEstudante){
    int idade = calcularIdade(dataNascimento);
    if(idade >=12 && idade <=15){
    valor *=0.6;
    }else if (idade >= 16 && idade <=20){
        valor *= 0.7;
    }else if (idade > 20){
        valor *=0.8;
    }
    }
    public void calculaDescontoHorário(){
    LocalTime horarioFilme = LocalTime.parse(horário);
    LocalTime horarioLimite=LocalTime.parse("16:00");
    if(horarioFilme.isBefore(horarioLimite)){
    valor *=0.9;
    }
    }
    private int calcularIdade(Data dataNascimento){
    LocalDate dataAtual = LocalDate.now();
    LocalDate dataNasc = LocalDate.of(dataNascimento.getAno(), dataNascimento.getMês(), dataNascimento.getDia());
    Period periodo = Period.between(dataNasc, dataAtual);
    return periodo.getYears();
    }
    private boolean horarioAntesDas16(){
    String[] partesHorário = horário.split(".");
    int hora = Integer.parseInt(partesHorário[0]);
    return hora<16;
    }
    @Override
    public String toString(){
    return "Data do filme: " + dataFilme+
    "\nHorário: " + horário +
    "\nSala: " + sala +
    "\nValor: R$" + valor;
    }
    
}
