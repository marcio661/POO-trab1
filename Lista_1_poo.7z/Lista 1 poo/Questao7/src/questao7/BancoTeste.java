
package questao7;

/**
 *
 * @author souza
 */
public class BancoTeste {
    public static void main(String[] args) {
        Banco banco = new Banco();

       
        banco.criarConta(1, true, 1000.0);
        banco.criarConta(2, false, 0.0);

        
        banco.depositar(1, 500.0);
        banco.sacar(1, 200.0);
        banco.sacar(2, 100.0);
        banco.emitirSaldo(1);
        banco.emitirExtrato(1);
        banco.emitirExtrato(2);
        banco.transferir(1, 2, 300.0);
        banco.emitirSaldo(1);
        banco.emitirSaldo(2);
    }
}
