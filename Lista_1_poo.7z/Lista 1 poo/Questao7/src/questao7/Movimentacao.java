
package questao7;

/**
 *
 * @author souza
 */
public class Movimentacao {
    public enum Tipo {
        CREDITO,
        DEBITO
    }

    private String descricao;
    private double valor;
    private Tipo tipo;

    public Movimentacao(String descricao, double valor, Tipo tipo) {
        this.descricao = descricao;
        this.valor = valor;
        this.tipo = tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getValor() {
        return valor;
    }

    public Tipo getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        String tipoMovimentacao = tipo == Tipo.CREDITO ? "Crédito" : "Débito";
        return descricao + " - " + tipoMovimentacao + " - R$" + valor;
    }
}
