
package questao7;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author souza
 */
public class Banco {
    private List<ContaCorrente> contas;

    public Banco() {
        this.contas = new ArrayList<>();
    }

    public void criarConta(int numero, boolean especial, double limite) {
        ContaCorrente conta = new ContaCorrente(numero, especial, limite);
        contas.add(conta);
    }

    public void excluirConta(int numero) {
        ContaCorrente conta = buscarConta(numero);
        if (conta != null) {
            contas.remove(conta);
        }
    }

    public void sacar(int numero, double valor) {
        ContaCorrente conta = buscarConta(numero);
        if (conta != null) {
            boolean saqueRealizado = conta.sacar(valor);
            if (saqueRealizado) {
                System.out.println("Saque realizado com sucesso.");
            } else {
                System.out.println("Saldo insuficiente.");
            }
        } else {
            System.out.println("Conta não encontrada.");
        }
    }

    public void depositar(int numero, double valor) {
        ContaCorrente conta = buscarConta(numero);
        if (conta != null) {
            conta.depositar(valor);
            System.out.println("Depósito realizado com sucesso.");
        } else {
            System.out.println("Conta não encontrada.");
        }
    }

    public void emitirSaldo(int numero) {
        ContaCorrente conta = buscarConta(numero);
        if (conta != null) {
            conta.emitirSaldo();
        } else {
            System.out.println("Conta não encontrada.");
        }
    }

    public void emitirExtrato(int numero) {
        ContaCorrente conta = buscarConta(numero);
        if (conta != null) {
            conta.emitirExtrato();
        } else {
            System.out.println("Conta não encontrada.");
        }
    }

    public void transferir(int numeroOrigem, int numeroDestino, double valor) {
        ContaCorrente contaOrigem = buscarConta(numeroOrigem);
        ContaCorrente contaDestino = buscarConta(numeroDestino);

        if (contaOrigem != null && contaDestino != null) {
            boolean saqueRealizado = contaOrigem.sacar(valor);
            if (saqueRealizado) {
                contaDestino.depositar(valor);
                System.out.println("Transferência realizada com sucesso.");
            } else {
                System.out.println("Saldo insuficiente.");
            }
        } else {
            System.out.println("Conta de origem ou destino não encontrada.");
        }
    }

    private ContaCorrente buscarConta(int numero) {
        for (ContaCorrente conta : contas) {
            if (conta.getNumero() == numero) {
                return conta;
            }
        }
        return null;
    }
}

