
package questao7;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author souza
 */
public class ContaCorrente {
    private int numero;
    private double saldo;
    private boolean especial;
    private double limite;
    private List<Movimentacao> movimentacoes;

    public ContaCorrente(int numero, boolean especial, double limite) {
        this.numero = numero;
        this.saldo = 0.0;
        this.especial = especial;
        this.limite = limite;
        this.movimentacoes = new ArrayList<>();
    }

    public int getNumero() {
        return numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public boolean isEspecial() {
        return especial;
    }

    public double getLimite() {
        return limite;
    }

    public List<Movimentacao> getMovimentacoes() {
        return movimentacoes;
    }

    public void depositar(double valor) {
        saldo += valor;
        Movimentacao movimentacao = new Movimentacao("Depósito", valor, Movimentacao.Tipo.CREDITO);
        movimentacoes.add(movimentacao);
    }

    public boolean sacar(double valor) {
        if (saldo + limite >= valor) {
            saldo -= valor;
            Movimentacao movimentacao = new Movimentacao("Saque", valor, Movimentacao.Tipo.DEBITO);
            movimentacoes.add(movimentacao);
            return true;
        } else {
            return false;
        }
    }

    public void emitirSaldo() {
        System.out.println("Saldo: R$" + saldo);
    }

    public void emitirExtrato() {
        System.out.println("Extrato:");
        for (Movimentacao movimentacao : movimentacoes) {
            System.out.println(movimentacao);
        }
    }
}
    

