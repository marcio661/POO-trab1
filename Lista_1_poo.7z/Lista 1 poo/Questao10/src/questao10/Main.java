
package questao10;

/**
 *
 * @author souza
 */
public class Main {

    
    public static void main(String[] args) {
        Notas notas = new Notas();
        notas.setTrabalho1(3);
        notas.setTrabalho2(4);
        notas.setTrabalho3(2);
        notas.setTrabalho4(1);
        notas.setprova1(7.8);
        notas.setprova2(8.2);
        double mediaFinal = notas.calcularMediaFinal();
        boolean aprovado = notas.verificarAprovacao();
        System.out.println("Média Final: " +mediaFinal);
        System.out.println("Aprovado: " +aprovado);
        
    }
    
}
